package br.com.luh.testeswagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteSwaggerApplication.class, args);
	}

}

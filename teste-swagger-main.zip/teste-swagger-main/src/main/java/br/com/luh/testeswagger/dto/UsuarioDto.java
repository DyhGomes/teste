package br.com.luh.testeswagger.dto;

public record UsuarioDto(
        String nome,
        int idade
) {
}

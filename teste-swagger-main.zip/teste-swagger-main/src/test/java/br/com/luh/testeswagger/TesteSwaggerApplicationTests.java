package br.com.luh.testeswagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteSwaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
